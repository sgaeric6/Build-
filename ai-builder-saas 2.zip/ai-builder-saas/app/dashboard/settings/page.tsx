"use client";

import { useState } from "react";
import { signOut } from "next-auth/react";

export default function SettingsPage() {
  const [subdomain, setSubdomain] = useState("");
  const [subdomainMsg, setSubdomainMsg] = useState("");

  const [projectId, setProjectId] = useState("");
  const [domain, setDomain] = useState("");
  const [domainMsg, setDomainMsg] = useState("");
  const [dnsRecords, setDnsRecords] = useState<any[]>([]);

  async function claimSubdomain() {
    setSubdomainMsg("Saving...");
    const res = await fetch("/api/subdomain", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subdomain }),
    });
    const data = await res.json();
    setSubdomainMsg(res.ok ? `Claimed: ${data.subdomain}.yourweb.com` : data.error);
  }

  async function submitDomain() {
    setDomainMsg("Saving...");
    const res = await fetch("/api/domains", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ projectId, domain }),
    });
    const data = await res.json();
    if (res.ok) {
      setDomainMsg("Domain added — set these DNS records at your registrar:");
      setDnsRecords(data.dnsRecords || []);
    } else {
      setDomainMsg(data.error);
    }
  }

  return (
    <main className="mx-auto max-w-xl space-y-8 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Settings</h1>
        <button onClick={() => signOut({ callbackUrl: "/" })} className="text-sm text-gray-500 underline">
          Sign out
        </button>
      </div>

      <section className="rounded border p-4">
        <h2 className="mb-2 font-medium">Your free subdomain</h2>
        <p className="mb-3 text-sm text-gray-500">
          Every project on the free plan is reachable at yourname.yourweb.com.
        </p>
        <div className="flex gap-2">
          <input
            value={subdomain}
            onChange={(e) => setSubdomain(e.target.value.toLowerCase())}
            placeholder="yourname"
            className="flex-1 rounded border px-3 py-2"
          />
          <button onClick={claimSubdomain} className="rounded bg-black px-4 py-2 text-white">
            Claim
          </button>
        </div>
        {subdomainMsg && <p className="mt-2 text-sm">{subdomainMsg}</p>}
      </section>

      <section className="rounded border p-4">
        <h2 className="mb-2 font-medium">Custom domain</h2>
        <p className="mb-3 text-sm text-gray-500">
          Requires the Pro plan or higher. Enter your project ID and the domain you own.
        </p>
        <div className="space-y-2">
          <input
            value={projectId}
            onChange={(e) => setProjectId(e.target.value)}
            placeholder="Project ID (from its dashboard URL)"
            className="w-full rounded border px-3 py-2"
          />
          <input
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            placeholder="yourdomain.com"
            className="w-full rounded border px-3 py-2"
          />
          <button onClick={submitDomain} className="rounded bg-black px-4 py-2 text-white">
            Connect domain
          </button>
        </div>
        {domainMsg && <p className="mt-2 text-sm">{domainMsg}</p>}
        {dnsRecords.length > 0 && (
          <pre className="mt-2 overflow-x-auto rounded bg-gray-100 p-3 text-xs">
            {JSON.stringify(dnsRecords, null, 2)}
          </pre>
        )}
      </section>
    </main>
  );
}
