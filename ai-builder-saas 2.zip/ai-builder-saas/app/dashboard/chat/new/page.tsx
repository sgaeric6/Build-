"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewProjectPage() {
  const [name, setName] = useState("");
  const router = useRouter();

  async function createProject() {
    const res = await fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
    const project = await res.json();
    router.push(`/dashboard/chat/${project.id}`);
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center gap-4 p-6">
      <h1 className="text-xl font-semibold">Name your project</h1>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="e.g. my-portfolio"
        className="rounded border px-3 py-2"
      />
      <button onClick={createProject} className="rounded bg-black px-4 py-2 text-white">
        Create & start building
      </button>
    </main>
  );
}
