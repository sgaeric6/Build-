export default function CheckEmailPage() {
  return (
    <main className="flex min-h-screen items-center justify-center p-6 text-center">
      <div>
        <h1 className="mb-2 text-2xl font-semibold">Check your email</h1>
        <p className="text-gray-500">
          We sent you a sign-in link. Click it to continue — you can close this tab.
        </p>
      </div>
    </main>
  );
}
