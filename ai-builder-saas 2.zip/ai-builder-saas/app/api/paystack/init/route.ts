import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { initializeTransaction } from "@/lib/paystack";

// Prices in kobo (NGN smallest unit) — adjust to your actual pricing.
const PLAN_PRICES: Record<string, number> = {
  PRO: 500000, // ₦5,000
  ADVANCED: 1500000, // ₦15,000
};

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { plan } = await req.json();
  const amount = PLAN_PRICES[plan];
  if (!amount) return NextResponse.json({ error: "Invalid plan" }, { status: 400 });

  const result = await initializeTransaction(session.user.email!, amount, {
    userId: (session.user as any).id,
    plan,
  });

  return NextResponse.json({ authorizationUrl: result.data.authorization_url });
}
