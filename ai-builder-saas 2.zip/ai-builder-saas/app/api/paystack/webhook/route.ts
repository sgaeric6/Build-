import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyWebhookSignature } from "@/lib/paystack";

// Configure this exact URL as your webhook in the Paystack dashboard:
// https://yourweb.com/api/paystack/webhook

export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get("x-paystack-signature") || "";

  if (!verifyWebhookSignature(rawBody, signature)) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  const event = JSON.parse(rawBody);

  if (event.event === "charge.success") {
    const { userId, plan } = event.data.metadata || {};
    if (userId && plan) {
      await prisma.user.update({ where: { id: userId }, data: { plan } });

      await prisma.subscription.upsert({
        where: { userId },
        create: {
          userId,
          plan,
          status: "active",
          paystackCustomerId: event.data.customer?.customer_code,
        },
        update: {
          plan,
          status: "active",
          paystackCustomerId: event.data.customer?.customer_code,
        },
      });
    }
  }

  if (event.event === "subscription.disable") {
    const customerCode = event.data.customer?.customer_code;
    const sub = await prisma.subscription.findFirst({
      where: { paystackCustomerId: customerCode },
    });
    if (sub) {
      await prisma.subscription.update({
        where: { id: sub.id },
        data: { status: "cancelled" },
      });
      await prisma.user.update({ where: { id: sub.userId }, data: { plan: "FREE" } });
    }
  }

  return NextResponse.json({ received: true });
}
