import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const SLUG_RE = /^[a-z0-9-]{3,30}$/;

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { subdomain } = await req.json();
  if (!SLUG_RE.test(subdomain)) {
    return NextResponse.json(
      { error: "Use 3-30 lowercase letters, numbers, or hyphens only" },
      { status: 400 }
    );
  }

  const existing = await prisma.user.findUnique({ where: { subdomain } });
  if (existing && existing.id !== (session.user as any).id) {
    return NextResponse.json({ error: "That subdomain is already taken" }, { status: 409 });
  }

  await prisma.user.update({
    where: { id: (session.user as any).id },
    data: { subdomain },
  });

  return NextResponse.json({ ok: true, subdomain });
}
