import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { addCustomDomain } from "@/lib/vercel";

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const userId = (session.user as any).id;
  const user = await prisma.user.findUnique({ where: { id: userId } });

  if (user?.plan === "FREE") {
    return NextResponse.json(
      { error: "Custom domains require the Pro plan or higher" },
      { status: 403 }
    );
  }

  const { projectId, domain } = await req.json();
  const project = await prisma.project.findFirst({ where: { id: projectId, userId } });
  if (!project?.vercelProjId) {
    return NextResponse.json({ error: "Project not deployed yet" }, { status: 400 });
  }

  const result = await addCustomDomain(project.vercelProjId, domain);

  await prisma.project.update({ where: { id: project.id }, data: { customDomain: domain } });

  // result.verification contains the DNS records the user needs to set
  return NextResponse.json({ ok: true, dnsRecords: result.verification || [] });
}
