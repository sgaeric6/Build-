import type { DefaultSession } from "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      plan: "FREE" | "PRO" | "ADVANCED";
      subdomain: string | null;
    } & DefaultSession["user"];
  }
}
