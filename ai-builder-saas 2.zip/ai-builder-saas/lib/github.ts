import { Octokit } from "@octokit/rest";

// Requires a GitHub Personal Access Token (or GitHub App token) with repo scope,
// stored as GITHUB_TOKEN in .env. The token's account/org owns all generated repos.
const octokit = new Octokit({ auth: process.env.GITHUB_TOKEN });
const OWNER = process.env.GITHUB_OWNER as string; // your GitHub username or org

export async function ensureRepo(repoName: string) {
  try {
    await octokit.repos.get({ owner: OWNER, repo: repoName });
  } catch (err: any) {
    if (err.status === 404) {
      await octokit.repos.createInOrg?.({ org: OWNER, name: repoName, private: true }).catch(
        // fall back to personal account if OWNER isn't an org
        async () => {
          await octokit.repos.createForAuthenticatedUser({ name: repoName, private: true });
        }
      );
    } else {
      throw err;
    }
  }
  return `${OWNER}/${repoName}`;
}

// Parses the model's "===FILE: path===\n...content...\n===END===" format
export function parseFileBlocks(raw: string): { path: string; content: string }[] {
  const blocks: { path: string; content: string }[] = [];
  const regex = /===FILE:\s*(.+?)\s*===\n([\s\S]*?)\n===END===/g;
  let match;
  while ((match = regex.exec(raw)) !== null) {
    blocks.push({ path: match[1].trim(), content: match[2] });
  }
  return blocks;
}

export async function commitFiles(
  repoName: string,
  files: { path: string; content: string }[],
  message: string
) {
  const branch = "main";

  // Get current commit SHA (or handle empty repo on first commit)
  let baseTreeSha: string | undefined;
  let parentSha: string | undefined;
  try {
    const ref = await octokit.git.getRef({ owner: OWNER, repo: repoName, ref: `heads/${branch}` });
    parentSha = ref.data.object.sha;
    const commit = await octokit.git.getCommit({ owner: OWNER, repo: repoName, commit_sha: parentSha });
    baseTreeSha = commit.data.tree.sha;
  } catch {
    // empty repo, no base tree yet
  }

  const tree = await octokit.git.createTree({
    owner: OWNER,
    repo: repoName,
    base_tree: baseTreeSha,
    tree: files.map((f) => ({
      path: f.path,
      mode: "100644",
      type: "blob",
      content: f.content,
    })) as any,
  });

  const commit = await octokit.git.createCommit({
    owner: OWNER,
    repo: repoName,
    message,
    tree: tree.data.sha,
    parents: parentSha ? [parentSha] : [],
  });

  await octokit.git.updateRef({
    owner: OWNER,
    repo: repoName,
    ref: `heads/${branch}`,
    sha: commit.data.sha,
    force: true,
  }).catch(async () => {
    // ref doesn't exist yet (first commit) — create it
    await octokit.git.createRef({
      owner: OWNER,
      repo: repoName,
      ref: `refs/heads/${branch}`,
      sha: commit.data.sha,
    });
  });

  return commit.data.sha;
}
